/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package asignacion7_252260.Pruebas;

import java.awt.Color;
import java.awt.Component;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/**
 *
 * @author chant
 */
public class ResaltarCeldasRenderer extends DefaultTableCellRenderer{
    private boolean[][] errores;

    public ResaltarCeldasRenderer(int filas, int columnas) {
        errores = new boolean[filas][columnas];
    }

    public void marcarError(int fila, int columna) {
        errores[fila][columna] = true;
    }

    public void limpiarErrores() {
        for (int i = 0; i < errores.length; i++)
            for (int j = 0; j < errores[0].length; j++)
                errores[i][j] = false;
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value,
            boolean isSelected, boolean hasFocus, int row, int column) {

        Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

        if (row < errores.length && column < errores[0].length && errores[row][column]) {
            c.setBackground(Color.PINK); // celda con error
        } else {
            c.setBackground(Color.WHITE); // celda normal
        }

        return c;
    }
}
